import MovieList from '@/components/movie/movie-page/movieList';

const MoviePage = async () => {
  return <MovieList />;
};

export default MoviePage;
