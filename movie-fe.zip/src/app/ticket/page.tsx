import Ticket from '@/components/ticket/ticket';

const TicketPage = () => {
  return <Ticket />;
};

export default TicketPage;
