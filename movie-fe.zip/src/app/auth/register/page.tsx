import Register from '@/components/auth/register';

const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;
