import History from '@/components/history/history';

const HistoryPage = () => {
  return <History />;
};

export default HistoryPage;
