import Payment from '@/components/payment/payment';

const PaymentPage = () => {
  return <Payment />;
};

export default PaymentPage;
